# douroucoulisay/__init__.py

# Example of initialization code or imports
from .douroucoulisay import douroucoulisay, tonal_hoot, gruff_hoot, whoop

# You can also define some package-level constants or variables
__version__ = "0.1.1.8"
__author__ = "Aotus Parisinus"
