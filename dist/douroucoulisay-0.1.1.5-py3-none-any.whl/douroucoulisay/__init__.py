# douroucoulisay/__init__.py

# Example of initialization code or imports
from douroucoulisay import douroucoulisay

# You can also define some package-level constants or variables
__version__ = "0.3.7"
__author__ = "Aotus Parisinus"
